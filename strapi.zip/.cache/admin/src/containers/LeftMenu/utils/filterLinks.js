const filterLinks = links => links.filter(link => link.isDisplayed);

export default filterLinks;
