const getRequestUrl = path => `/admin/${path}`;

export default getRequestUrl;
