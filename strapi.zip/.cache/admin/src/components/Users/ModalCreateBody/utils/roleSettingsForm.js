import RolesSelectComponent from '../../RoleSettingsModalSection/RolesSelectComponent';

const roleSettingsForm = {
  roles: {
    label: 'Settings.permissions.users.form.firstname',
    Component: RolesSelectComponent,
  },
};

export default roleSettingsForm;
